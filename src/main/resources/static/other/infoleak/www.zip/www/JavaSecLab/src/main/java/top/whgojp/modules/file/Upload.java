package top.whgojp.modules.file;

import io.swagger.annotations.Api;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * @description 任意文件类-文件上传
 * @author: whgojp
 * @email: whgojp@foxmail.com
 * @Date: 2024/7/8 15:57
 */
@Slf4j
@Api(value = "UploadController", tags = "任意文件类-文件上传")
@Controller
@CrossOrigin(origins = "*")
@RequestMapping("/file/upload")
public class Upload {
    @RequestMapping("")
    public String fileUpload() {
        return "vul/file/upload";
    }
}
