package top.whgojp.common.push.service;

/**
 * @description 邮件推送
 * @author: whgojp
 * @email: whgojp@foxmail.com
 * @Date: 2024/6/14 16:05
 */
public interface EmailPush {
    void send();
}
