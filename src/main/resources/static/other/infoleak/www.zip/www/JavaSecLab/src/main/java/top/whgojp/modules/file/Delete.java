package top.whgojp.modules.file;

import io.swagger.annotations.Api;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * @description 任意文件类-文件删除
 * @author: whgojp
 * @email: whgojp@foxmail.com
 * @Date: 2024/7/8 15:59
 */
@Slf4j
@Api(value = "DeleteController", tags = "任意文件类-文件删除")
@Controller
@CrossOrigin(origins = "*")
@RequestMapping("/file/delete")
public class Delete {
    @RequestMapping("")
    public String fileDelete() {
        return "vul/file/delete";
    }
}
