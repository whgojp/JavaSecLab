package top.whgojp.common.push.service;

/**
 * @description 飞书推送
 * @author: whgojp
 * @email: whgojp@foxmail.com
 * @Date: 2024/6/14 16:03
 */
public interface FeiShuPush {
}
