package top.whgojp.common.push.service;

/**
 * @description 微信推送
 * @author: whgojp
 * @email: whgojp@foxmail.com
 * @Date: 2024/6/14 16:04
 */
public interface WechatPush {
}
