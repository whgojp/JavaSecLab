package top.whgojp.modules.infoleak.controller;

import io.swagger.annotations.Api;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * @description 敏感信息泄漏-测试页面
 * @author: whgojp
 * @email: whgojp@foxmail.com
 * @Date: 2024/7/19 13:07
 */
@Slf4j
@Api(value = "CeshiController", tags = "敏感信息泄漏-测试页面")
@Controller
@CrossOrigin(origins = "*")
@RequestMapping("/infoLeak/ceShiPage")
public class CeshiController {
    @RequestMapping("")
    public String CeShi() {
        return "vul/infoLeak/ceshi";
    }

}
