package top.whgojp.common.push.service.impl;

import top.whgojp.common.push.service.SmsPush;

/**
 * @description <功能描述>
 * @author: whgojp
 * @email: whgojp@foxmail.com
 * @Date: 2024/6/14 16:10
 */
public class SmsPushImpl implements SmsPush {

}
