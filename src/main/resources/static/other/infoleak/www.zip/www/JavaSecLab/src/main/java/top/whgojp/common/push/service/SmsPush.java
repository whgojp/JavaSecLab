package top.whgojp.common.push.service;

/**
 * @description 短信推送
 * @author: whgojp
 * @email: whgojp@foxmail.com
 * @Date: 2024/6/14 16:04
 */
public interface SmsPush {
}
