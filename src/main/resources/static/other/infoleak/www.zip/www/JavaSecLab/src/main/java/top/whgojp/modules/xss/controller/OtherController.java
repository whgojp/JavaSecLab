package top.whgojp.modules.xss.controller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.FilenameUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ResourceLoader;
import org.springframework.http.HttpRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import top.whgojp.common.utils.R;
import cn.hutool.core.date.DateUtil;
import top.whgojp.common.utils.UploadUtil;

import javax.servlet.http.HttpServletRequest;
import java.io.BufferedWriter;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;


/**
 * @description 跨站脚本-其他场景
 * @author: whgojp
 * @email: whgojp@foxmail.com
 * @Date: 2024/5/23 13:59
 */
@Slf4j
@Api(value = "OtherController", tags = "跨站脚本-其他场景")
@Controller
@CrossOrigin(origins = "*")
@RequestMapping("/xss/other")
public class OtherController {
    @Autowired
    private ResourceLoader resourceLoader;

    @RequestMapping("")
    public String xssOther() {
        return "vul/xss/other";
    }

    @RequestMapping("/jquery-xss")
    public String jqueryXss() {
        return "vul/xss/jquery-xss";
    }

    @RequestMapping("/receive")
    @ResponseBody
    public R hackCookie(@RequestParam String cookie, HttpServletRequest request) {
        String currentTime = DateUtil.now();
        String remoteHost = request.getRemoteHost();

        String logMessage = "Data: " + currentTime + " Source IP: " + remoteHost + " User Cookie: " + cookie;
        log.info("Data: " + currentTime + " Source IP: " + remoteHost + " User Cookie: " + cookie);
        String filePath = "src/main/resources/static/other/cookie.txt";

        // 使用 try-with-resources 来自动关闭 FileWriter 和 BufferedWriter
        try (BufferedWriter writer = Files.newBufferedWriter(Paths.get(filePath), StandardOpenOption.CREATE, StandardOpenOption.APPEND)) {
            writer.write(logMessage);
            writer.newLine(); // 换行
        } catch (IOException e) {
            e.printStackTrace(); // 这里可以根据实际情况处理异常
        }
        return R.ok(cookie);
    }

    @Autowired
    private UploadUtil uploadUtil;

    // 文件上传接口
    @ApiOperation(value = "漏洞环境：文件上传导致存储XSS", notes = "原生漏洞环境,未加任何过滤，Controller接口返回Json类型结果")
    @RequestMapping("/a-vul1-upload")
    @ResponseBody
    @SneakyThrows
    public R vul1Upload(@RequestParam("file") MultipartFile file, @ApiParam(name = "type", value = "类型", required = true) @RequestParam String type, HttpServletRequest request) {
        String res;
        String suffix = FilenameUtils.getExtension(file.getOriginalFilename());
        switch (type) {
            case "html":
            case "xml":
            case "svg":
            case "swf":
            case "pdf":
                log.info("后缀名：" + suffix);
                res = uploadUtil.uploadFile(file, suffix);
                break;
            default:
                res = "上传错误，请检查后重新上传！";
        }
        return R.ok(res);
    }

    @ApiOperation(value = "漏洞环境：文件上传导致存储XSS", notes = "原生漏洞环境,未加任何过滤，Controller接口返回Json类型结果")
    @RequestMapping("/a-vul2-template")
    public String vul2Template(@ApiParam(name = "type", value = "类型", required = true) @RequestParam String type,
                               @ApiParam(name = "content", value = "请求参数", required = true) @RequestParam String content,
                               Model model) {
        String res = "";
        switch (type) {
            case "html":
                model.addAttribute("vul2TemplateHtml", content);
                model.addAttribute("vul2TemplateText", "");
                res = "收到的数据：" + content;
                break;
            case "text":
                model.addAttribute("vul2TemplateText", content);
                model.addAttribute("vul2TemplateHtml", "");
                res = "收到的数据：" + content;
                break;
            default:
                model.addAttribute("vul2TemplateText", "上传错误，请检查后重新上传！");
                model.addAttribute("vul2TemplateHtml", "");
                break;
        }
        log.info(res);
        return "vul/xss/other"; // 返回视图名称
    }

}
