package top.whgojp.modules.file;

import io.swagger.annotations.Api;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * @description <功能描述>
 * @author: whgojp
 * @email: whgojp@foxmail.com
 * @Date: 2024/7/9 17:31
 */
@Slf4j
@Api(value = "ReadController", tags = "任意文件类-文件读取")
@Controller
@CrossOrigin(origins = "*")
@RequestMapping("/file/read")
public class Read {
    @RequestMapping("")
    public String fileRead() {
        return "vul/file/read";
    }
}
