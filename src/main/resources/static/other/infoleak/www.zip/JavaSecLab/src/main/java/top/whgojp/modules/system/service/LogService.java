package top.whgojp.modules.system.service;

import top.whgojp.modules.system.entity.Log;
import com.baomidou.mybatisplus.extension.service.IService;

/**
* @author whgojp
* @description 针对表【log】的数据库操作Service
* @createDate 2024-06-14 17:54:54
*/
public interface LogService extends IService<Log> {

}
