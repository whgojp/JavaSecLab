package top.whgojp.modules.system.mapper;

import top.whgojp.modules.system.entity.Log;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
* @author whgojp
* @description 针对表【log】的数据库操作Mapper
* @createDate 2024-06-14 17:54:54
* @Entity top.whgojp.modules.system.entity.Log
*/
public interface LogMapper extends BaseMapper<Log> {

}




