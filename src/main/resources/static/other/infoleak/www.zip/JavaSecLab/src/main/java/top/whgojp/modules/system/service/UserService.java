package top.whgojp.modules.system.service;

import top.whgojp.modules.system.entity.User;
import com.baomidou.mybatisplus.extension.service.IService;

/**
* @author whgojp
* @description 针对表【user】的数据库操作Service
* @createDate 2024-06-13 20:53:06
*/
public interface UserService extends IService<User> {
    User userLogin(String username,String oldPassword);

    // 修改密码
    int changePassword(String username,String newPass);
}
