package test;

/**
 * @description 字节码文件
 * @author: whgojp
 * @email: whgojp@foxmail.com
 * @Date: 2024/5/22 10:40
 */
public class Test {
    public static void main(String[] args) {
        System.out.println("Hello whgojp!");
    }
}
