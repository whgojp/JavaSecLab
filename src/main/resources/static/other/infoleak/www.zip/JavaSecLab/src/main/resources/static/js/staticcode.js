/**
 * @description 存放静态代码
 * @author:  whgojp
 * @email:  whgojp@foxmail.com
 * @Date: 2024/5/19 19:03
 */
const vul1ReflectRaw = "// 原生漏洞环境,未加任何过滤，Controller接口返回Json类型结果\n" +
    "@RequestMapping(\"/a-vul1-reflect-raw\")  // 可接收各种请求类型\n" +
    "public R vul1ReflectRaw(@ApiParam(name = \"type\", value = \"请求参数\", required = true) @RequestParam String content) {\n" +
    "\n" +
    "    return R.ok(content);\n" +
    "}\n" +
    "// R 是对返回结果的封装工具util\n" +
    "// 返回结果：\n" +
    "// {\n" +
    "//     \"msg\": \"<script>alert(document.cookie)</script>\",\n" +
    "//     \"code\": 0\n" +
    "// }\n" +
    "// payload在json中是不会触发xss的 需要解析到页面中\n" +
    "\n" +
    "// 原生漏洞环境,未加任何过滤，Controller接口返回String类型结果\n" +
    "public String vul1ReflectRawString(@ApiParam(name = \"type\", value = \"请求参数\", required = true) @RequestParam String content) {\n" +
    "\n" +
    "    return content;\n" +
    "}"
const vul2ReflectContentType = "// Tomcat内置HttpServletResponse，Content-Type导致反射XSS\n" +
    "public void vul2ReflectContentType(@ApiParam(name = \"type\", value = \"类型\", required = true) @RequestParam String type, @ApiParam(name = \"content\", value = \"请求参数\", required = true) @RequestParam String content, HttpServletResponse response) {\n" +
    "    switch (type) {\n" +
    "        case \"html\":\n" +
    "            response.getWriter().print(content);\n" +
    "            response.setContentType(\"text/html;charset=utf-8\");\n" +
    "            response.getWriter().flush();\n" +
    "            break;\n" +
    "        case \"plain\":\n" +
    "            response.getWriter().print(content);\n" +
    "            response.setContentType(\"text/plain;charset=utf-8\");\n" +
    "            response.getWriter().flush();\n" +
    "            ...\n" +
    "    }\n" +
    "}"
const safe1CheckUserInput = "// 对用户输入的数据进行验证和过滤，确保不包含恶意代码。使用白名单过滤，只允许特定类型的输入，如纯文本或指定格式的数据\n" +
    "// 前端校验代码\n" +
    "var whitelistRegex = /^[a-zA-Z0-9_\\s]+$/;\n" +
    "\n" +
    "// 检查输入值是否符合白名单要求\n" +
    "if (!whitelistRegex.test(value)) {\n" +
    "\tlayer.msg('输入内容包含非法字符，请检查输入', {icon: 2, offset: '10px'});\n" +
    "\treturn false; // 取消表单提交\n" +
    "    } else {\n" +
    "    \t// 正常发送请求\n" +
    "    }\n" +
    "\n" +
    "// 后端校验代码\n" +
    "private static final String WHITELIST_REGEX = \"^[a-zA-Z0-9_\\\\s]+$\";\n" +
    "private static final Pattern pattern = Pattern.compile(WHITELIST_REGEX);\n" +
    "\n" +
    "Matcher matcher = pattern.matcher(content);\n" +
    "if (matcher.matches()){\n" +
    "    return R.ok(content);\n" +
    "}else return R.error(\"输入内容包含非法字符，请检查输入\");"
const safe2CSP = "// 内容安全策略（Content Security Policy）是一种由浏览器实施的安全机制，旨在减少和防范跨站脚本攻击（XSS）等安全威胁。它通过允许网站管理员定义哪些内容来源是可信任的，从而防止恶意内容的加载和执行\n" +
    "// 前端Meta配置\n" +
    "<meta http-equiv=\"Content-Security-Policy\" content=\"default-src 'self'; script-src 'self' https://apis.example.com; style-src 'self' https://fonts.googleapis.com; img-src 'self' data: https://*.example.com;\">\n" +
    "\n" +
    "\n" +
    "// 后端Header配置\n" +
    "@ApiImplicitParam(name = \"content\", value = \"请求参数\", dataType = \"String\", paramType = \"query\", dataTypeClass = String.class)\n" +
    "public String safe2CSP(@ApiParam(name = \"content\", value = \"请求参数\", required = true) @RequestParam String content,HttpServletResponse response) {\n" +
    "    response.setHeader(\"Content-Security-Policy\",\"default-src self\");\n" +
    "    return content;\n" +
    "}"

const safe3EntityEscape = '// 特殊字符实体转义是一种将 HTML 中的特殊字符转换为预定义实体表示的过程。\n' +
    '// 这种转义是为了确保在 HTML 页面中正确显示特定字符，同时避免它们被浏览器误解为 HTML 标签或JavaScript代码的一部分，从而导致页面结构混乱或安全漏洞。\n' +
    'public R safe3EntityEscape(@ApiParam(name = "type", value = "类型", required = true) @RequestParam String type, @ApiParam(name = "content", value = "请求参数", required = true) @RequestParam String content) {\n' +
    '    String filterContented = "";\n' +
    '    switch (type){\n' +
    '        case "manual":\n' +
    '            content = StringUtils.replace(content, "&", "&amp;");\n' +
    '            content = StringUtils.replace(content, "<", "&lt;");\n' +
    '            content = StringUtils.replace(content, ">", "&gt;");\n' +
    '            content = StringUtils.replace(content, "\\"", "&quot;");\n' +
    '            content = StringUtils.replace(content, "\'", "&#x27;");\n' +
    '            content = StringUtils.replace(content, "/", "&#x2F;");\n' +
    '            filterContented = content;\n' +
    '            break;\n' +
    '        case "spring":\n' +
    '            filterContented = HtmlUtils.htmlEscape(content);\n' +
    '            break;\n' +
    '            ...\n' +
    '    }\n' +
    '}'

const safe4HttpOnly = "// HttpOnly是HTTP响应头属性，用于增强Web应用程序安全性。它防止客户端脚本访问(只能通过http/https协议访问)带有HttpOnly标记的 cookie，从而减少跨站点脚本攻击（XSS）的风险。\n" +
    "// 单个接口配置\n" +
    "public R safe4HttpOnly(@ApiParam(name = \"content\", value = \"请求参数\", required = true) String content, HttpServletRequest request,HttpServletResponse response) {\n" +
    "    Cookie cookie = request.getCookies()[1];\n" +
    "    cookie.setHttpOnly(true); // 设置为 HttpOnly\n" +
    "    cookie.setMaxAge(600);  // 这里设置生效时间为十分钟\n" +
    "    cookie.setPath(\"/\");\n" +
    "    response.addCookie(cookie);\n" +
    "    return R.ok(content);\n" +
    "}\n" +
    "\n" +
    "// 全局配置\n" +
    "// 1、application.yml配置\n" +
    "server:\n" +
    "  servlet:\n" +
    "    session:\n" +
    "      cookie:\n" +
    "        http-only: true\n" +
    "\n" +
    "// 2、Springboot配置类\n" +
    "@Configuration\n" +
    "public class ServerConfig {\n" +
    "    @Bean\n" +
    "    public WebServerFactoryCustomizer<ConfigurableWebServerFactory> webServerFactoryCustomizer() {\n" +
    "        return factory -> {\n" +
    "            Session session = new Session();\n" +
    "            session.getCookie().setHttpOnly(true);\n" +
    "            factory.setSession(session);\n" +
    "            ...\n" +
    "}\n"

const vul1StoreRaw = "// 原生漏洞环境,未加任何过滤，将用户输入存储到数据库中\n" +
    "// Controller层\n" +
    "public R vul1StoreRaw(@ApiParam(name = \"content\", value = \"请求参数\", required = true) @RequestParam String content,HttpServletRequest request) {\n" +
    "    String ua = request.getHeader(\"User-Agent\");\n" +
    "    final int code = xssService.insertOne(content,ua);\n" +
    "    ...\n" +
    "}\n" +
    "// Service层\n" +
    "public int insertOne(String content, String ua) {\n" +
    "    final int code = xssMapper.insertAll(content,ua,DateUtil.now());\n" +
    "    return code;\n" +
    "}\n" +
    "// Mapper层\n" +
    "int insertAll(String content,String ua,String date);\n" +
    "\n" +
    "<insert id=\"insertAll\">\n" +
    "    insert into xss\n" +
    "        (content,ua, date)\n" +
    "    values (#{content,jdbcType=VARCHAR},#{ua,jdbcType=VARCHAR}, #{date,jdbcType=VARCHAR})\n" +
    "</insert>"

const safe1StoreEntityEscape = "// 表格数据渲染\n" +
    "table.render({\n" +
    "\t...\n" +
    "    cols: [\n" +
    "        {field: 'id', title: 'ID', sort: true, width: '60', fixed: 'left'},\n" +
    "        {field: 'content', title: 'Content', width: '200', templet: function(d){\n" +
    "                return escapeHtml(d.content); \n" +
    "            }},\n" +
    "        {field: 'ua', title: 'User-Agent', width: '200', templet: function(d){\n" +
    "                return escapeHtml(d.ua); \n" +
    "            }},\n" +
    "      \t...\n" +
    "// 方法一、HTML 实体转义函数\n" +
    "function escapeHtml(html) {\n" +
    "    var text = document.createElement(\"textarea\");\n" +
    "    text.textContent = html;\n" +
    "    return text.innerHTML;\n" +
    "}\n" +
    "// 方法二、JavaScript的文本节点\n" +
    "var textNode = document.createTextNode(htmlContent);\n" +
    "element.appendChild(textNode);\n" +
    "// 方法三、jQuery的text()方法\n" +
    "$('#element').text(htmlContent);\n"

const vul1DomRaw = "// innerHTML\n" +
    "form.on('submit(vul1-dom-raw)', function (data) {\n" +
    "    var userInput = document.getElementById('vul1-dom-raw-input').value;\n" +
    "    var outputDiv = document.getElementById('vul-dom-raw-result');\n" +
    "    outputDiv.innerHTML = userInput;\n" +
    "    return false;\n" +
    "});\n" +
    "\n" +
    "// 跳转场景\n" +
    "var hash = location.hash;\n" +
    "if(hash){\n" +
    "    var url = hash.substring(1);\n" +
    "    console.log(url);\n" +
    "    location.href = url;\n" +
    "}"

const vul1OtherUpload = "vul1OtherUpload"

const vul2OtherTemplate = "vul2OtherTemplate"

const vul1RawJoint = "// 原生sql语句动态拼接 参数未进行任何处理\n" +
    "public R vul1RawJoint(@ApiParam(name = \"type\", value = \"操作类型\", required = true) @RequestParam String type,@ApiParam(name = \"id\", value = \"用户ID\") @RequestParam(required = false) String id,@ApiParam(name = \"username\", value = \"用户名\") @RequestParam(required = false) String username,@ApiParam(name = \"password\", value = \"密码\") @RequestParam(required = false) String password) {\n" +
    "    //注册数据库驱动类\n" +
    "    Class.forName(\"com.mysql.cj.jdbc.Driver\");\n" +
    "\n" +
    "    //调用DriverManager.getConnection()方法创建Connection连接到数据库\n" +
    "    Connection conn = DriverManager.getConnection(dbUrl, dbUser, dbPass);\n" +
    "\n" +
    "    //调用Connection的createStatement()或prepareStatement()方法 创建Statement对象\n" +
    "    Statement stmt = conn.createStatement();\n" +
    "    switch (type) {\n" +
    "        case \"add\":\n" +
    "            sql = \"INSERT INTO users (user, pass) VALUES ('\" + username + \"', '\" + password + \"')\"; //这里没有标识id id自增长\n" +
    "            //通过Statement对象执行SQL语句，得到ResultSet对象-查询结果集\n" +
    "            rowsAffected = stmt.executeUpdate(sql);         // 这里注意一下 insert、update、delete 语句应使用executeUpdate()\n" +
    "            //关闭ResultSet结果集 Statement对象 以及数据库Connection对象 释放资源\n" +
    "            stmt.close();\n" +
    "            conn.close();\n" +
    "            return R.ok(message);\n" +
    "        case \"delete\":\n" +
    "            sql = \"DELETE FROM users WHERE id = '\" + id + \"'\";\n" +
    "            rowsAffected = stmt.executeUpdate(sql);\n" +
    "            ...\n" +
    "        case \"update\":\n" +
    "            sql = \"UPDATE users SET pass = '\" + password + \"', user = '\" + username + \"' WHERE id = '\" + id + \"'\";\n" +
    "            rowsAffected = stmt.executeUpdate(sql);\n" +
    "            ...\n" +
    "        case \"select\":\n" +
    "            sql = \"SELECT * FROM users WHERE id  = \" + id;\n" +
    "            ResultSet rs = stmt.executeQuery(sql);\n" +
    "            ...\n" +
    "        }\n" +
    "}"

const vul2prepareStatementJoint = "// 虽然使用了 conn.prepareStatement(sql) 创建了一个 PreparedStatement 对象，但在执行 stmt.executeUpdate(sql) 时，却是传递了完整的 SQL 语句作为参数，而不是使用了预编译的功能\n" +
    "public R vul2prepareStatementJoint(@ApiParam(name = \"type\", value = \"操作类型\", required = true) @RequestParam String type,@ApiParam(name = \"id\", value = \"用户ID\") @RequestParam(required = false) String id,@ApiParam(name = \"username\", value = \"用户名\") @RequestParam(required = false) String username,@ApiParam(name = \"password\", value = \"密码\") @RequestParam(required = false) String password) {\n" +
    "    Class.forName(\"com.mysql.cj.jdbc.Driver\");\n" +
    "    Connection conn = DriverManager.getConnection(dbUrl, dbUser, dbPass);\n" +
    "    PreparedStatement stmt;\n" +
    "    switch (type) {\n" +
    "        case \"add\":\n" +
    "            sql = \"INSERT INTO users (user, pass) VALUES ('\" + username + \"', '\" + password + \"')\";\n" +
    "            stmt = conn.prepareStatement(sql);\n" +
    "            rowsAffected = stmt.executeUpdate(sql);\n" +
    "            ...\n" +
    "        case \"delete\":\n" +
    "            sql = \"DELETE FROM users WHERE id = '\" + id + \"'\";\n" +
    "            stmt = conn.prepareStatement(sql);\n" +
    "            rowsAffected = stmt.executeUpdate(sql);\n" +
    "            ...\n" +
    "        case \"update\":\n" +
    "            sql = \"UPDATE users set pass = '\" + password + \"' where id = '\" + id + \"'\";\n" +
    "            stmt = conn.prepareStatement(sql);\n" +
    "            rowsAffected = stmt.executeUpdate(sql);\n" +
    "            ...\n" +
    "        case \"select\":\n" +
    "            sql = \"SELECT * FROM users WHERE id  = \" + id;\n" +
    "            stmt = conn.prepareStatement(sql);\n" +
    "            ResultSet rs = stmt.executeQuery(sql);\n" +
    "            ...\n" +
    "    }\n" +
    "}"
const vul3JdbcTemplateJoint = "// JDBCTemplate是Spring对JDBC的封装，底层实现实际上还是JDBC\n" +
    "public R vul3JdbcTemplateJoint(@ApiParam(name = \"type\", value = \"操作类型\", required = true) @RequestParam String type,@ApiParam(name = \"id\", value = \"用户ID\") @RequestParam(required = false) String id,@ApiParam(name = \"username\", value = \"用户名\") @RequestParam(required = false) String username,@ApiParam(name = \"password\", value = \"密码\") @RequestParam(required = false) String password) {\n" +
    "    DriverManagerDataSource dataSource = new DriverManagerDataSource();\n" +
    "    dataSource.setDriverClassName(\"com.mysql.cj.jdbc.Driver\");\n" +
    "    dataSource.setUrl(dbUrl);\n" +
    "    dataSource.setUsername(dbUser);\n" +
    "    dataSource.setPassword(dbPass);\n" +
    "    JdbcTemplate jdbctemplate = new JdbcTemplate(dataSource);\n" +
    "    switch (type) {\n" +
    "        case \"add\":\n" +
    "            sql = \"INSERT INTO users (user, pass) VALUES ('\" + username + \"', '\" + password + \"')\";\n" +
    "            rowsAffected = jdbctemplate.update(sql);        //Spring的JdbcTemplate会自动管理连接的获取和释放，不需要手动关闭连接\n" +
    "            ...\n" +
    "        case \"delete\":\n" +
    "            sql = \"DELETE FROM users WHERE id = '\" + id + \"'\";\n" +
    "            rowsAffected = jdbctemplate.update(sql);\n" +
    "            ...\n" +
    "        case \"update\":\n" +
    "            sql = \"UPDATE users set pass = '\" + password + \"' where id = '\" + id + \"'\";\n" +
    "            rowsAffected = jdbctemplate.update(sql);\n" +
    "            ...\n" +
    "        case \"select\":\n" +
    "            sql = \"SELECT * FROM users WHERE id  = \" + id;\n" +
    "            stringObjectMap = jdbctemplate.queryForMap(sql);\n" +
    "            ...\n" +
    "    }\n" +
    "}"
const safe1PrepareStatementParametric = "// 采用预编译的方法，使用?占位，也叫参数化的SQL\n" +
    "public R safe1PrepareStatementParametric(@ApiParam(name = \"type\", value = \"操作类型\", required = true) @RequestParam String type,@ApiParam(name = \"id\", value = \"用户ID\") @RequestParam(required = false) String id,@ApiParam(name = \"username\", value = \"用户名\") @RequestParam(required = false) String username,@ApiParam(name = \"password\", value = \"密码\") @RequestParam(required = false) String password) {\n" +
    "    Class.forName(\"com.mysql.cj.jdbc.Driver\");\n" +
    "    Connection conn = DriverManager.getConnection(dbUrl, dbUser, dbPass);\n" +
    "    PreparedStatement stmt;\n" +
    "    switch (type) {\n" +
    "        case \"add\":\n" +
    "            sql = \"INSERT INTO users (user, pass) VALUES (?, ?)\"; // 这里可以看到使用了?占位符 sql语句和参数进行分离\n" +
    "            stmt = conn.prepareStatement(sql);\n" +
    "            stmt.setString(1, username); // 参数化处理\n" +
    "            stmt.setString(2, password);\n" +
    "            rowsAffected = stmt.executeUpdate(); // 使用预编译时 不需要传递sql语句\n" +
    "\n" +
    "        case \"delete\":\n" +
    "            sql = \"DELETE FROM users WHERE id = ?\";\n" +
    "            stmt = conn.prepareStatement(sql);\n" +
    "            stmt.setString(1, id);\n" +
    "            rowsAffected = stmt.executeUpdate();\n" +
    "            ...\n" +
    "        case \"update\":\n" +
    "            sql = \"UPDATE users set pass = ? where id = ?\";\n" +
    "            stmt = conn.prepareStatement(sql);\n" +
    "            stmt.setString(1, password);\n" +
    "            stmt.setString(2, id);\n" +
    "            rowsAffected = stmt.executeUpdate();\n" +
    "            ...\n" +
    "        case \"select\":\n" +
    "            sql = \"SELECT * FROM users WHERE id  = ?\";\n" +
    "            stmt = conn.prepareStatement(sql);\n" +
    "            stmt.setString(1, id);\n" +
    "            ResultSet rs = stmt.executeQuery();\n" +
    "            ...\n" +
    "   }\n" +
    "}"
const safe2JdbcTemplatePrepareStatementParametric = "// JDBCTemplate预编译 此时在常规DML场景有效的防止了SQL注入攻击的发生\n" +
    "public R safe2JdbcTemplatePrepareStatementParametric(@ApiParam(name = \"type\", value = \"操作类型\", required = true) @RequestParam String type,@ApiParam(name = \"id\", value = \"用户ID\") @RequestParam(required = false) String id,@ApiParam(name = \"username\", value = \"用户名\") @RequestParam(required = false) String username,@ApiParam(name = \"password\", value = \"密码\") @RequestParam(required = false) String password) {\n" +
    "    DriverManagerDataSource dataSource = new DriverManagerDataSource();\n" +
    "    dataSource.setDriverClassName(\"com.mysql.cj.jdbc.Driver\");\n" +
    "    dataSource.setUrl(dbUrl);\n" +
    "    dataSource.setUsername(dbUser);\n" +
    "    dataSource.setPassword(dbPass);\n" +
    "    JdbcTemplate jdbctemplate = new JdbcTemplate(dataSource);\n" +
    "    switch (type) {\n" +
    "        case \"add\":\n" +
    "            sql = \"INSERT INTO users (user, pass) VALUES (?,?)\";\n" +
    "            rowsAffected = jdbctemplate.update(sql, username, password);\n" +
    "            ...\n" +
    "        case \"delete\":\n" +
    "            sql = \"DELETE FROM users WHERE id = ?\";\n" +
    "            rowsAffected = jdbctemplate.update(sql, id);\n" +
    "            ...\n" +
    "        case \"update\":\n" +
    "            sql = \"UPDATE users set pass = ? where id = ?\";\n" +
    "            rowsAffected = jdbctemplate.update(sql, username, id);\n" +
    "            ...\n" +
    "        case \"select\":\n" +
    "            sql = \"SELECT * FROM users WHERE id  = ?\";\n" +
    "            stringObjectMap = jdbctemplate.queryForMap(sql, id);\n" +
    "            ...\n" +
    "    }\n" +
    "}"
const safe3BlacklistcheckSqlBlackList = "// 检测用户输入是否存在敏感字符：'、;、--、+、,、%、=、>、<、*、(、)、and、or、exeinsert、select、delete、update、count、drop、chr、midmaster、truncate、char、declare\n" +
    "public R safe3BlacklistcheckSqlBlackList(@ApiParam(name = \"type\", value = \"操作类型\", required = true) @RequestParam String type,\n" +
    "    @ApiParam(name = \"id\", value = \"用户ID\") @RequestParam(required = false) String id,@ApiParam(name = \"username\", value = \"用户名\") @RequestParam(required = false) String username,@ApiParam(name = \"password\", value = \"密码\") @RequestParam(required = false) String password) {\n" +
    "    Class.forName(\"com.mysql.cj.jdbc.Driver\");\n" +
    "    Connection conn = DriverManager.getConnection(dbUrl, dbUser, dbPass);\n" +
    "    Statement stmt = conn.createStatement();\n" +
    "    switch (type) {\n" +
    "        case \"add\":\n" +
    "            if (checkUserInput.checkSqlBlackList(username) || checkUserInput.checkSqlBlackList(password)) {\n" +
    "                return R.error(\"黑名单检测到非法SQL注入!\");\n" +
    "            } else {\n" +
    "                sql = \"INSERT INTO users (user, pass) VALUES ('\" + username + \"', '\" + password + \"')\";\n" +
    "                rowsAffected = stmt.executeUpdate(sql);\n" +
    "                ...\n" +
    "        case \"delete\":\n" +
    "            if (checkUserInput.checkSqlBlackList(id)) {\n" +
    "                return R.error(\"黑名单检测到非法SQL注入!\");\n" +
    "            } else {\n" +
    "                sql = \"DELETE FROM users WHERE id = '\" + id + \"'\";\n" +
    "                rowsAffected = stmt.executeUpdate(sql);\n" +
    "                ...\n" +
    "        case \"update\":\n" +
    "            if (checkUserInput.checkSqlBlackList(id) || checkUserInput.checkSqlBlackList(username) || checkUserInput.checkSqlBlackList(id)) {\n" +
    "                return R.error(\"黑名单检测到非法SQL注入!\");\n" +
    "            } else {\n" +
    "                sql = \"UPDATE users SET pass = '\" + password + \"', user = '\" + username + \"' WHERE id = '\" + id + \"'\";\n" +
    "                log.info(\"当前执行数据更新操作:\" + sql);\n" +
    "                rowsAffected = stmt.executeUpdate(sql);\n" +
    "                ...\n" +
    "        case \"select\":\n" +
    "            if (checkUserInput.checkSqlBlackList(id)) {\n" +
    "                return R.error(\"黑名单检测到非法SQL注入!\");\n" +
    "            } else {\n" +
    "                sql = \"SELECT * FROM users WHERE id  = \" + id;\n" +
    "                ResultSet rs = stmt.executeQuery(sql);\n" +
    "                ...\n" +
    "    }\n" +
    "}"
const safe4RequestRarameterValidate = "// 强制类型转换 对用户请求参数进行校验\n" +
    "public R safe4RequestRarameterValidate(@ApiParam(name = \"id\", value = \"用户ID\") @RequestParam(required = false) Integer id) {\n" +
    "    Class.forName(\"com.mysql.cj.jdbc.Driver\");\n" +
    "    Connection conn = DriverManager.getConnection(dbUrl, dbUser, dbPass);\n" +
    "    Statement stmt = conn.createStatement();\n" +
    "    message = checkUserInput.checkUser(id);\n" +
    "    if (!message.isEmpty()) return R.error(message);\n" +
    "    sql = \"SELECT * FROM users WHERE id  = \" + id;\n" +
    "    log.info(\"当前执行数据查询操作:\" + sql);\n" +
    "    ResultSet rs = stmt.executeQuery(sql);\n" +
    "    ...\n" +
    "}"
const safe4EASAPIFilter = "// ESAPI提供了多种输入验证API，提供对XSS攻击和SQL注入攻击等的防护\n" +
    "public R safe4EASAPIFilter(@ApiParam(name = \"id\", value = \"用户ID\") @RequestParam(required = false) String id) {\n" +
    "    Codec<Character> oracleCodec = new OracleCodec();\n" +
    "    Class.forName(\"com.mysql.cj.jdbc.Driver\");\n" +
    "    Connection conn = DriverManager.getConnection(dbUrl, dbUser, dbPass);\n" +
    "\n" +
    "    Statement stmt = conn.createStatement();\n" +
    "    // 使用了 Oracle 的编解码器 OracleCodec 和 ESAPI 库来对 ID 进行编码，以防止 SQL 注入攻击。\n" +
    "//            String sql = \"select * from users where id = '\" + ESAPI.encoder().encodeForSQL(oracleCodec, id) + \"'\";\n" +
    "    String sql = \"select * from users where id = '\" + id + \"'\";\n" +
    "    log.info(\"当前执行数据查询操作:\" + sql);\n" +
    "    ResultSet rs = stmt.executeQuery(sql);\n" +
    "   \n" +
    "}"
const special1OrderBy = "// ORDER BY关键字用于按升序或降序对结果集进行排序。 由于order by后面需要紧跟column_name，而预编译是参数化字符串，而order by后面紧跟字符串就会不支持原有功能 使用默认排序，因此通常防御order by注入需要使用白名单的方式\n" +
    "public R special1OrderBy(@ApiParam(name = \"type\", value = \"操作类型\", required = true) @RequestParam String type,@ApiParam(name = \"field\", value = \"字段名\") @RequestParam(required = false) String field) {\n" +
    "    Class.forName(\"com.mysql.cj.jdbc.Driver\");\n" +
    "    Connection conn = DriverManager.getConnection(dbUrl, dbUser, dbPass);\n" +
    "    PreparedStatement preparedStatement;\n" +
    "    switch (type) {\n" +
    "        case \"raw\":\n" +
    "            sql = \"SELECT * FROM users ORDER BY \" + field;\n" +
    "            preparedStatement = conn.prepareStatement(sql);\n" +
    "            rs = preparedStatement.executeQuery();\n" +
    "            ...\n" +
    "        case \"prepareStatement\":\n" +
    "            // 可以测试下 预编译没有报错 不过插入语句不生效 默认使用主键升序\n" +
    "            sql = \"select * from users order by ?\";\n" +
    "            preparedStatement = conn.prepareStatement(sql);\n" +
    "            preparedStatement.setString(1, field);\n" +
    "            rs = preparedStatement.executeQuery();\n" +
    "            ...\n" +
    "        case \"writeList\":\n" +
    "            sql = \"SELECT * FROM users ORDER BY \" + field;\n" +
    "            if (checkUserInput.chechSqlWhiteList(field)) {\n" +
    "                return R.error(\"field字段不合法！\");\n" +
    "            }\n" +
    "            log.info(\"当前执行数据排序操作：\" + sql + \" 参数：\" + field);\n" +
    "            preparedStatement = conn.prepareStatement(sql);\n" +
    "            rs = preparedStatement.executeQuery();\n" +
    "   }\n" +
    "}"
const special2Like = "// \n" +
    "public R special2Like(@ApiParam(name = \"type\", value = \"操作类型\", required = true) @RequestParam String type,@ApiParam(name = \"keyword\", value = \"关键词\") @RequestParam(required = false) String keyword) {\n" +
    "    Class.forName(\"com.mysql.cj.jdbc.Driver\");\n" +
    "    Connection conn = DriverManager.getConnection(dbUrl, dbUser, dbPass);\n" +
    "    PreparedStatement preparedStatement;\n" +
    "    switch (type) {\n" +
    "        case \"inside\":\n" +
    "            sql = \"SELECT * FROM users WHERE user LIKE '%?%'\";\n" +
    "            preparedStatement = conn.prepareStatement(sql);\n" +
    "            preparedStatement.setString(1, keyword);\n" +
    "            rs = preparedStatement.executeQuery();\n" +
    "            ...\n" +
    "        case \"outside\":\n" +
    "            sql = \"SELECT * FROM users WHERE user LIKE ?\";\n" +
    "            preparedStatement = conn.prepareStatement(sql);\n" +
    "            preparedStatement.setString(1, \"%\"+keyword+\"%\");\n" +
    "            rs = preparedStatement.executeQuery();\n" +
    "            ...\n" +
    "    }\n" +
    "}"

// 水洞系列
const vul1SpringMvcRedirect = "// 基于Spring MVC的重定向方式\n" +
    "// 通过返回带有 redirect: 前缀的字符串来实现重定向。\n" +
    "@GetMapping(\"/redirect\")\n" +
    "public String vul1SpringMvc(@RequestParam(\"url\") String url) {\n" +
    "    return \"redirect:\" + url;   // Spring MVC写法 302临时重定向\n" +
    "}\n" +
    "\n" +
    "// 通过返回 ModelAndView 对象并指定 redirect: 前缀来实现重定向。\n" +
    "@RequestMapping(\"/redirectWithModelAndView\")\n" +
    "public ModelAndView vul1ModelAndView(@RequestParam(\"url\") String url) {\n" +
    "    return new ModelAndView(\"redirect:\" + url); // Spring MVC写法 使用ModelAndView 302临时重定向\n" +
    "}";

const vul2ServletRedirect = "// 基于Servlet标准的重定向方式\n" +
    "// 通过设置响应状态码和头部信息实现重定向。\n" +
    "@RequestMapping(\"/setHeader\")\n" +
    "@ResponseBody\n" +
    "public static void vul2setHeader(HttpServletRequest request, HttpServletResponse response) {\n" +
    "    String url = request.getParameter(\"url\");\n" +
    "    response.setStatus(HttpServletResponse.SC_MOVED_PERMANENTLY); // 301永久重定向\n" +
    "    response.setHeader(\"Location\", url);\n" +
    "}\n" +
    "\n" +
    "// 通过调用 HttpServletResponse.sendRedirect() 实现重定向。\n" +
    "@RequestMapping(\"/sendRedirect\")\n" +
    "@ResponseBody\n" +
    "public static void vul2sendRedirect(HttpServletRequest request, HttpServletResponse response) throws IOException {\n" +
    "    String url = request.getParameter(\"url\");\n" +
    "    response.sendRedirect(url); // 302临时重定向\n" +
    "}";

const vul3SpringRedirect = "// 基于Spring注解和状态码的重定向方式\n" +
    "// 使用ResponseEntity设置状态码实现重定向\n" +
    "@RequestMapping(\"/responseEntityRedirect\")\n" +
    "@ResponseBody\n" +
    "public ResponseEntity<Void> responseEntityRedirect(@RequestParam(\"url\") String url) {\n" +
    "    HttpHeaders headers = new HttpHeaders();\n" +
    "    headers.setLocation(URI.create(url));\n" +
    "    return new ResponseEntity<>(headers, HttpStatus.FOUND); // 302临时重定向\n" +
    "}\n" +
    "\n" +
    "// 通过注解设置状态码实现重定向\n" +
    "@GetMapping(\"/annotationRedirect\")\n" +
    "@ResponseStatus(HttpStatus.FOUND) // 302临时重定向\n" +
    "public void annotationRedirect(HttpServletRequest request, HttpServletResponse response) throws IOException {\n" +
    "    String url = request.getParameter(\"url\");\n" +
    "    response.setHeader(\"Location\", url);\n" +
    "}";
const safe1Forward = "// 内部跳转\n" +
    "@RequestMapping(\"/forward\")\n" +
    "@ResponseBody\n" +
    "public static void safe1Forward(HttpServletRequest request, HttpServletResponse response) {\n" +
    "    String url = request.getParameter(\"url\");\n" +
    "    RequestDispatcher rd = request.getRequestDispatcher(url);\n" +
    "    try {\n" +
    "        rd.forward(request, response);\n" +
    "        log.info(\"做了内部转发……\");\n" +
    "    } catch (Exception e) {\n" +
    "        e.printStackTrace();\n" +
    "    }\n" +
    "}";
const safe2CheckUrl = '// 定义 URL 黑名单\n' +
    'private static final List<String> blackUrlList = new ArrayList<>();\n' +
    '\n' +
    'static {\n' +
    '    blackUrlList.add("baidu.com");\n' +
    '    blackUrlList.add("csdn.net");\n' +
    '}\n' +
    '/**\n' +
    ' * URL跳转过滤\n' +
    ' */\n' +
    'public boolean checkURL(String url) {\n' +
    '    for (String blackUrl : blackUrlList){\n' +
    '        if (url.toLowerCase().contains(blackUrl.toLowerCase())){\n' +
    '            return false;\n' +
    '        }}\n' +
    '    return true;\n' +
    '}';
const vul1Xffforgery = "xff";


const infoLeakJs = "function s() {\n" +
    "    return s = Object(o[\"a\"])(Object(r[\"a\"])().mark((function e(t) {\n" +
    "        var n, o;\n" +
    "        return Object(r[\"a\"])().wrap((function (e) {\n" +
    "            while (1) switch (e.prev = e.next) {\n" +
    "                case 0:\n" +
    "                    return n = (new Date).getTime(), o = \"uploads/\".concat(n, \"_\").concat(t.name), e.abrupt(\"return\", new Promise((function (e, n) {\n" +
    "                        var r = new i({\n" +
    "                            SecretId: \"AKID4xax3skP8jyDs6SZS5SZR5TcfSyC9p9H\",\n" +
    "                            SecretKey: \"vaz81e2B5j89iYB5FtIRJvHPIvJRJvHO\"\n" +
    "                        });\n" +
    "                        r.uploadFile({\n" +
    "                            Bucket: \"official-website-1305607643\",\n" +
    "                            Region: \"ap-beijing\",\n" +
    "                            Key: o,\n" +
    "                            Body: t,\n" +
    "                            SliceSize: 5242880\n" +
    "                        }, (function (t, r) {\n" +
    "                            t ? n(\"上传失败\") : e({\n" +
    "                                code: 200,\n" +
    "                                data: {path: \"https://official-website-1305887643.cos.ap-beijing.myqcloud.com/\".concat(o)}\n" +
    "                            })\n" +
    "                        }))\n" +
    "                    })));\n" +
    "                case 3:\n" +
    "                case\"end\":\n" +
    "                    return e.stop()\n" +
    "            }\n" +
    "        }), e)\n" +
    "    }))), s.apply(this, arguments)\n" +
    "}";

const dirTraversal = '@GetMapping("/listdir")\n' +
    '@ResponseBody\n' +
    'public String listDirectory(@RequestParam String dir) {\n' +
    '    String staticFolderPath = sysConstant.getStaticFolder();\n' +
    '    File baseDir = new File(staticFolderPath);\n' +
    '    File requestedDir = new File(baseDir, dir);\n' +
    '\n' +
    '    // 生成HTML输出\n' +
    '    StringBuilder response = new StringBuilder();\n' +
    '    response.append("<!DOCTYPE HTML>");\n' +
    '    ...\n' +
    '\n' +
    '    File[] files = requestedDir.listFiles();\n' +
    '    if (files != null) {\n' +
    '        for (File file : files) {\n' +
    '            response.append("<li>");\n' +
    '            if (file.isDirectory()) {\n' +
    '                response.append("<a href=\\"?dir=").append(dir);\n' +
    '                if (!dir.endsWith("/")) {\n' +
    '                    response.append("/");\n' +
    '                }\n' +
    '                response.append(file.getName()).append("/\\">").append(file.getName()).append("/</a>");\n' +
    '    ...\n' +
    '    return response.toString();\n' +
    '}';

const safeListDirectory = "@GetMapping(\"/safelistdir\")\n" +
    "@ResponseBody\n" +
    "public String safeListDirectory(@RequestParam String dir) {\n" +
    "    String staticFolderPath = sysConstant.getStaticFolder();\n" +
    "    File baseDir = new File(staticFolderPath);\n" +
    "    File requestedDir = new File(baseDir, dir);\n" +
    "\n" +
    "    // 检查请求的目录是否在规定目录内\n" +
    "try {\n" +
    "    if (!requestedDir.getCanonicalPath().startsWith(baseDir.getCanonicalPath()) || !requestedDir.isDirectory()) {\n" +
    "        return \"Directory not found or access denied.\";\n" +
    "    }\n" +
    "} catch (IOException e) {\n" +
    "    return \"Error resolving directory path.\";\n" +
    "}\n" +
    "...";