package top.whgojp.modules.file;

import io.swagger.annotations.Api;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * @description 任意文件类-文件包含
 * @author: whgojp
 * @email: whgojp@foxmail.com
 * @Date: 2024/7/9 17:30
 */
@Slf4j
@Api(value = "IncludeController", tags = "任意文件类-文件包含")
@Controller
@CrossOrigin(origins = "*")
@RequestMapping("/file/include")
public class Include {

    @RequestMapping("")
    public String fileInclude() {
        return "vul/file/include";
    }
}
