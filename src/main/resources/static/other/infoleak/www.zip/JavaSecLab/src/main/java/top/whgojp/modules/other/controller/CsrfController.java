package top.whgojp.modules.other.controller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * @description <功能描述>
 * @author: whgojp
 * @email: whgojp@foxmail.com
 * @Date: 2024/7/12 22:12
 */
@Slf4j
@Api(value = "CsrfController", tags = "其他漏洞-跨站请求伪造")
@Controller
@CrossOrigin(origins = "*")
@RequestMapping("/other/csrf")
public class CsrfController {
    @ApiOperation("")
    @RequestMapping("")
    public String csrf() {
        return "vul/other/csrf";
    }
}
